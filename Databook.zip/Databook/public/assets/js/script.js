function searchData() {
    const searchType = document.getElementById("searchType").value;
    const searchQuery = document.getElementById("searchQuery").value.trim();
    const resultDataElement = document.getElementById("resultData");
    const resultTableBody = document.getElementById("resultTable").getElementsByTagName('tbody')[0];

    if (!searchQuery) {
        resultTableBody.innerHTML = '';
        document.getElementById('searchQuery').value = '';
        resultDataElement.textContent = "Por favor ingrese un valor para buscar.";
        return;
    }

    if (searchType === "nut" && searchQuery.length !==10 ) {
        resultTableBody.innerHTML = '';
        document.getElementById('searchQuery').value = '';
        resultDataElement.textContent = "El NUT debe tener 10 dígitos exactos";
        return;
    }

    resultDataElement.textContent = "Cargando resultados...";

    
    // Hacer una solicitud GET al servidor con los parámetros searchType y searchQuery
    fetch(`/buscar?searchType=${searchType}&searchQuery=${encodeURIComponent(searchQuery)}`)
        .then(response => response.json())
        .then(data => {
            resultTableBody.innerHTML = '';


            // No se encontraron datos
            if (!data || data.length === 0) {
                if (searchType === "nombre") {
                    resultDataElement.textContent = `No se encontraron resultados para ${searchType}: ${searchQuery}. Si desea buscar en DATABOOK realice una búsqueda por cédula.`;
                    return;
                } else if (searchType === "nut") {
                    resultDataElement.textContent = "No se encontraron resultados en el JSON. Consultando API DATABOOK...";

                    
                    fetch(`http://localhost:3000/buscarAPI?nut=${encodeURIComponent(searchQuery)}`)
                        .then(response => response.json())
                        .then(apiData => {
                            console.log("Datos recibidos de la API:", apiData);

                            if (!apiData || !apiData.registros || !apiData.registros.socio_demografico) {
                                resultDataElement.textContent("No se encontraron datos en DATABOOK. Estructura incorrecta o vacía en apiData:", apiData);
                                return;
                            }

                            const socioDemografico = apiData.registros.socio_demografico;
                            
                            const rowElement = document.createElement("tr"); // Asegurar que esté definido

                            const nutCell = document.createElement("td");
                            nutCell.textContent = socioDemografico.nut || '';
                            rowElement.appendChild(nutCell);

                            const nameCell = document.createElement("td");
                            nameCell.textContent = socioDemografico.nombre || '';
                            rowElement.appendChild(nameCell);

                            const birthCell = document.createElement("td");
                            birthCell.textContent = socioDemografico.fecha_1 || '';
                            rowElement.appendChild(birthCell);

                            const actionCell = document.createElement("td");
                            const detailButton = document.createElement("button");
                            detailButton.textContent = "Detalle";
                            detailButton.onclick = function () {
                                showDetails(socioDemografico.nut);
                            };
                            actionCell.appendChild(detailButton);
                            rowElement.appendChild(actionCell);

                            resultTableBody.appendChild(rowElement);
                        })
                        .catch(error => {
                            resultDataElement.textContent = "Error al consultar API DATABOOK.", error;
                        });

                    resultDataElement.textContent = "Resultado del API DATABOOK...";
                    return;
                }
            }


            // Llenar la tabla con los resultados
            data.forEach(row => {
                const rowElement = document.createElement("tr");

                const nutCell = document.createElement("td");
                nutCell.textContent = row.socio_demografico.nut || '';
                rowElement.appendChild(nutCell);
                

                const nameCell = document.createElement("td");
                nameCell.textContent = row.socio_demografico.nombre || '';
                rowElement.appendChild(nameCell);

                const birthCell = document.createElement("td");
                birthCell.textContent = row.socio_demografico.fecha_1 || '';
                rowElement.appendChild(birthCell);

                const actionCell = document.createElement("td");
                const detailButton = document.createElement("button");
                detailButton.textContent = "Detalle";
                detailButton.onclick = function () {
                    showDetails(row.socio_demografico.nut);
                };
                actionCell.appendChild(detailButton);
                rowElement.appendChild(actionCell);

                resultTableBody.appendChild(rowElement);
            });

            resultDataElement.textContent = "Datos encontrados en el JSON.";
        })
        .catch(error => {
            resultDataElement.textContent = "Error al obtener los datos del JSON.", error;
            console.error(error);
        });

    document.getElementById('searchQuery').value = '';
}

function showDetails(nut) {
    // Buscar el registro completo utilizando el NUT
    fetch(`/buscar?searchType=nut&searchQuery=${encodeURIComponent(nut)}`)
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                // Suponiendo que el NUT es único, tomamos el primer resultado
                const registro = data[0];  // El primer registro encontrado

                // Mostrar los detalles en formato JSON en el <pre> con id 'resultData'
                document.getElementById("resultData").textContent = JSON.stringify(registro, null, 2);
            } else {
                document.getElementById("resultData").textContent = "No se encontraron detalles para el NUT: " + nut;
            }
        })
        .catch(error => {
            document.getElementById("resultData").textContent = "Error al obtener los detalles del registro.", error;
        });
}

// Evento para ejecutar searchData() cuando se presiona Enter en los campos de texto
document.getElementById('searchQuery').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        searchData();
    }
});

